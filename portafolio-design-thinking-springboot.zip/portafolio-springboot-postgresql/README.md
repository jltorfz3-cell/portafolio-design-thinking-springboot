# Portafolio Design Thinking Backend
Spring Boot 3.5 + Java 21 + PostgreSQL 17 + JPA + Security/JWT.

1. Crear la BD ejecutando `portafolio_design_thinking_postgresql.sql`.
2. Editar `src/main/resources/application.properties`.
3. Ejecutar: `mvn spring-boot:run`.
4. Swagger: `http://localhost:8080/swagger-ui.html`.

Endpoints base: `/api/auth/login`, `/api/auth/me`, `/api/proyectos`, `/api/etapas`.
